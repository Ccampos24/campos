-- Preserva o histórico da venda mesmo quando o veículo for excluído.
-- Execute no Supabase SQL Editor antes de testar a exclusão.

ALTER TABLE public.sales
  ADD COLUMN IF NOT EXISTS vehicle_label text,
  ADD COLUMN IF NOT EXISTS plate text;

-- Salva nos campos de histórico os dados dos veículos já vinculados às vendas.
UPDATE public.sales s
SET vehicle_label = COALESCE(NULLIF(s.vehicle_label, ''), concat_ws(' ', v.brand, v.model)),
    plate = COALESCE(NULLIF(s.plate, ''), v.plate)
FROM public.vehicles v
WHERE s.vehicle_id = v.id
  AND (s.vehicle_label IS NULL OR s.vehicle_label = '' OR s.plate IS NULL OR s.plate = '');

-- Permite que a venda permaneça sem vínculo depois da exclusão do veículo.
ALTER TABLE public.sales ALTER COLUMN vehicle_id DROP NOT NULL;
ALTER TABLE public.sales DROP CONSTRAINT IF EXISTS sales_vehicle_id_fkey;
ALTER TABLE public.sales
  ADD CONSTRAINT sales_vehicle_id_fkey
  FOREIGN KEY (vehicle_id)
  REFERENCES public.vehicles(id)
  ON DELETE SET NULL;

NOTIFY pgrst, 'reload schema';
