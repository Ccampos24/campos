ATUALIZAÇÃO — PRESERVAR HISTÓRICO DAS VENDAS

1. No Supabase, abra SQL Editor > New query.
2. Execute o arquivo PRESERVAR_VENDAS_AO_EXCLUIR_VEICULO.sql.
3. Publique/substitua o index.html atualizado da pasta autog no mesmo local onde hospeda o sistema.
4. Atualize o navegador com Ctrl+F5.

Agora, ao excluir um veículo, a venda permanece registrada e mantém modelo/placa no snapshot da venda. A venda só é excluída pelo botão Excluir na própria aba Vendas.

O SQL não apaga vendas. Ele preenche o snapshot das vendas que ainda estão vinculadas aos veículos e configura a relação para definir vehicle_id como NULL quando o veículo for removido.
Faça backup do banco antes de aplicar mudanças estruturais.
