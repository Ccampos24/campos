MÓDULO DOCUMENTAÇÃO — CAMPOS AUTOGESTÃO

1. No Supabase, abra SQL Editor e execute DOCUMENTACAO_SETUP.sql.
2. Publique o index.html atualizado junto dos arquivos de imagem já existentes.
3. Entre no sistema e abra a aba Documentação.
4. Adicione CRLV, contratos, comprovantes ou outros documentos. Arquivos PDF/imagem até 15 MB.
5. A vinculação com veículo é opcional. Se o veículo for removido, o documento permanece guardado sem vínculo.

Os arquivos ficam em bucket privado, com acesso restrito ao usuário autenticado proprietário. A interface cria links temporários para abrir arquivos.

Alertas: vencido, vence em até 30 dias, em dia ou sem vencimento. Datas são informativas; não há envio automático de notificações externas.
