-- Execute no SQL Editor do Supabase antes de usar a versão atualizada.
-- Campo para registrar o detalhamento dos custos adicionais por venda.
ALTER TABLE public.sales
  ADD COLUMN IF NOT EXISTS extra_cost_notes text;

-- Recalcular o lucro das vendas já existentes abatendo a comissão salva.
-- Os custos extras já eram abatidos anteriormente.
UPDATE public.sales
SET net_profit = COALESCE(sale_value, 0)
               - COALESCE(purchase_value, 0)
               - COALESCE(extra_costs, 0)
               - COALESCE(commission_amount, 0);
