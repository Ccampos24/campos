# Documentação com múltiplos arquivos

A tela permite selecionar vários arquivos no mesmo envio. Cada arquivo gera um registro individual em `vehicle_documents`, associado ao usuário e veículo selecionados. O limite continua em 15 MB por arquivo.

## Instalação
1. Faça backup da versão atual.
2. Execute `DOCUMENTACAO_SETUP.sql` no SQL Editor do Supabase, caso ainda não tenha sido executado.
3. Publique o `index.html` atualizado mantendo os demais arquivos estáticos.
4. Atualize o navegador com Ctrl+F5.

Não é necessário criar uma nova tabela: `vehicle_documents` já armazena um registro por arquivo.
