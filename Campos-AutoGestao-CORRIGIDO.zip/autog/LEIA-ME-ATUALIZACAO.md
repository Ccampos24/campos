# Atualização — comissão e custos adicionais

1. Faça uma cópia de segurança do projeto e do banco antes de atualizar.
2. No Supabase, abra **SQL Editor**, cole e execute `ATUALIZACAO_CUSTOS_COMISSAO.sql`.
3. Publique/substitua os arquivos do sistema pelo conteúdo desta pasta, mantendo suas configurações atuais de hospedagem.

## O que mudou
- O lucro líquido da venda agora desconta valor de compra, custos extras e comissão do vendedor.
- O lucro prévio no formulário é recalculado ao mudar o valor da venda, os custos ou o vendedor.
- Novo campo para descrever os custos adicionais da venda.
- O relatório detalhado de impressão exibe os custos adicionais, a observação desses custos, a comissão e o lucro líquido.
- A tabela do relatório e a exportação CSV também incluem a observação dos custos adicionais.
- O SQL adiciona o novo campo e recalcula o lucro líquido das vendas já registradas.

**Importante:** execute o SQL antes de usar o site atualizado; sem isso, o banco não reconhecerá `extra_cost_notes`.
