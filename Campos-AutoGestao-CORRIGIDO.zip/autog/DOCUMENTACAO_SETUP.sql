-- Campos AutoGestão: módulo Documentação (execute uma vez no Supabase SQL Editor)
CREATE TABLE IF NOT EXISTS public.vehicle_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_id UUID NULL REFERENCES public.vehicles(id) ON DELETE SET NULL,
  doc_type TEXT NOT NULL,
  title TEXT NOT NULL,
  expires_at DATE NULL,
  file_path TEXT NOT NULL,
  notes TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_vehicle_documents_owner ON public.vehicle_documents(owner_id);
CREATE INDEX IF NOT EXISTS idx_vehicle_documents_vehicle ON public.vehicle_documents(vehicle_id);
ALTER TABLE public.vehicle_documents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users view own vehicle documents" ON public.vehicle_documents;
DROP POLICY IF EXISTS "Users insert own vehicle documents" ON public.vehicle_documents;
DROP POLICY IF EXISTS "Users update own vehicle documents" ON public.vehicle_documents;
DROP POLICY IF EXISTS "Users delete own vehicle documents" ON public.vehicle_documents;
CREATE POLICY "Users view own vehicle documents" ON public.vehicle_documents FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "Users insert own vehicle documents" ON public.vehicle_documents FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Users update own vehicle documents" ON public.vehicle_documents FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Users delete own vehicle documents" ON public.vehicle_documents FOR DELETE TO authenticated USING (owner_id = auth.uid());

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('vehicle-documents','vehicle-documents',false,15728640,ARRAY['application/pdf','image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO UPDATE SET public=false, file_size_limit=15728640, allowed_mime_types=ARRAY['application/pdf','image/jpeg','image/png','image/webp'];
DROP POLICY IF EXISTS "Users read own vehicle document files" ON storage.objects;
DROP POLICY IF EXISTS "Users upload own vehicle document files" ON storage.objects;
DROP POLICY IF EXISTS "Users delete own vehicle document files" ON storage.objects;
CREATE POLICY "Users read own vehicle document files" ON storage.objects FOR SELECT TO authenticated USING (bucket_id='vehicle-documents' AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY "Users upload own vehicle document files" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='vehicle-documents' AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY "Users delete own vehicle document files" ON storage.objects FOR DELETE TO authenticated USING (bucket_id='vehicle-documents' AND (storage.foldername(name))[1]=auth.uid()::text);
NOTIFY pgrst, 'reload schema';
