-- Etapa 12 - anexos de print nos relatos de problemas
ALTER TABLE public.system_feedback
  ADD COLUMN IF NOT EXISTS attachment_path text;

-- Bucket privado para os prints enviados pelos usuários.
insert into storage.buckets (id, name, public)
values ('system-feedback', 'system-feedback', false)
on conflict (id) do update set public = false;

-- Cada usuário pode enviar e consultar somente os próprios arquivos.
drop policy if exists "feedback_storage_user_insert" on storage.objects;
create policy "feedback_storage_user_insert"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'system-feedback'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "feedback_storage_user_select" on storage.objects;
create policy "feedback_storage_user_select"
on storage.objects for select to authenticated
using (
  bucket_id = 'system-feedback'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
        and p.role = 'admin'
        and p.status = 'aprovado'
    )
  )
);

drop policy if exists "feedback_storage_user_delete" on storage.objects;
create policy "feedback_storage_user_delete"
on storage.objects for delete to authenticated
using (
  bucket_id = 'system-feedback'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
        and p.role = 'admin'
        and p.status = 'aprovado'
    )
  )
);

notify pgrst, 'reload schema';
