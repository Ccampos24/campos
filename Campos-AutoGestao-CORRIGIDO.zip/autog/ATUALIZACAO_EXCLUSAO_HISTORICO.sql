-- CAMPOS AUTOGESTÃO — Permitir exclusão do histórico pelo administrador geral
-- Execute no Supabase SQL Editor. Idempotente: pode ser executado mais de uma vez.

begin;

drop policy if exists audit_admin_delete on public.audit_logs;

create policy audit_admin_delete
on public.audit_logs
for delete
to authenticated
using (public.is_admin());

grant delete on table public.audit_logs to authenticated;

commit;
