-- Isolamento por conta do Campos AutoGestão (Supabase)
-- Faça backup antes de executar. Dados antigos sem proprietário ficam atribuídos ao administrador aprovado.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['vehicles','sales','customers','finance','sellers'] LOOP
    EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE CASCADE', t);
    -- Compatibilidade com registros antigos que já guardam created_by.
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='created_by') THEN
      EXECUTE format('UPDATE public.%I SET owner_id=created_by WHERE owner_id IS NULL AND created_by IS NOT NULL', t);
    END IF;
    -- Registros sem autor são atribuídos ao primeiro administrador aprovado.
    EXECUTE format('UPDATE public.%I SET owner_id=(SELECT id FROM public.profiles WHERE role=''admin'' AND status=''aprovado'' ORDER BY created_at LIMIT 1) WHERE owner_id IS NULL', t);
    EXECUTE format('ALTER TABLE public.%I ALTER COLUMN owner_id SET NOT NULL', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    -- Remove políticas anteriores dessas tabelas para evitar permissões abertas que se somem às novas.
    EXECUTE (SELECT string_agg(format('DROP POLICY IF EXISTS %I ON public.%I;', policyname, t), ' ') FROM pg_policies WHERE schemaname='public' AND tablename=t);
    EXECUTE format('CREATE POLICY tenant_select ON public.%I FOR SELECT TO authenticated USING (owner_id=auth.uid())', t);
    EXECUTE format('CREATE POLICY tenant_insert ON public.%I FOR INSERT TO authenticated WITH CHECK (owner_id=auth.uid())', t);
    EXECUTE format('CREATE POLICY tenant_update ON public.%I FOR UPDATE TO authenticated USING (owner_id=auth.uid()) WITH CHECK (owner_id=auth.uid())', t);
    EXECUTE format('CREATE POLICY tenant_delete ON public.%I FOR DELETE TO authenticated USING (owner_id=auth.uid())', t);
  END LOOP;
END $$;

-- O perfil administrativo continua separado: os usuários cadastrados podem ser aprovados/reprovados no módulo Administração.
NOTIFY pgrst, 'reload schema';
