create table if not exists public.system_settings (
  id boolean primary key default true,
  company_name text not null default 'Campos Tecnologia',
  company_document text,
  company_phone text,
  company_whatsapp text,
  company_email text,
  company_address text,
  currency text not null default 'BRL',
  date_format text not null default 'DD/MM/YYYY',
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now(),
  constraint system_settings_singleton check (id = true)
);
insert into public.system_settings (id) values (true) on conflict (id) do nothing;
alter table public.system_settings enable row level security;
drop policy if exists "system_settings_auth_select" on public.system_settings;
drop policy if exists "system_settings_admin_select" on public.system_settings;
drop policy if exists "system_settings_admin_insert" on public.system_settings;
drop policy if exists "system_settings_admin_update" on public.system_settings;
create policy "system_settings_auth_select" on public.system_settings for select to authenticated using (true);
create policy "system_settings_admin_insert" on public.system_settings for insert to authenticated with check (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado'));
create policy "system_settings_admin_update" on public.system_settings for update to authenticated using (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado')) with check (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado'));

create table if not exists public.system_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category text not null default 'erro',
  subject text not null,
  description text not null,
  status text not null default 'aberto',
  admin_response text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id),
  constraint system_feedback_category_check check (category in ('erro','problema_tecnico','duvida','sugestao','outro')),
  constraint system_feedback_status_check check (status in ('aberto','em_analise','resolvido','fechado'))
);
alter table public.system_feedback enable row level security;
drop policy if exists "feedback_user_select" on public.system_feedback;
drop policy if exists "feedback_user_insert" on public.system_feedback;
drop policy if exists "feedback_admin_select" on public.system_feedback;
drop policy if exists "feedback_admin_update" on public.system_feedback;
create policy "feedback_user_select" on public.system_feedback for select to authenticated using (user_id=auth.uid());
create policy "feedback_user_insert" on public.system_feedback for insert to authenticated with check (user_id=auth.uid());
create policy "feedback_admin_select" on public.system_feedback for select to authenticated using (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado'));
create policy "feedback_admin_update" on public.system_feedback for update to authenticated using (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado')) with check (exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.status='aprovado'));
notify pgrst, 'reload schema';
