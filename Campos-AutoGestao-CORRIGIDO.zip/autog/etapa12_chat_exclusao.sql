-- Etapa 12 - chat nos relatos + exclusão
create table if not exists public.system_feedback_messages (
  id uuid primary key default gen_random_uuid(),
  feedback_id uuid not null references public.system_feedback(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  sender_role text not null default 'user' check (sender_role in ('user','admin')),
  message text not null,
  created_at timestamptz not null default now()
);

alter table public.system_feedback_messages enable row level security;

drop policy if exists "feedback_messages_select" on public.system_feedback_messages;
drop policy if exists "feedback_messages_insert" on public.system_feedback_messages;
create policy "feedback_messages_select"
on public.system_feedback_messages for select to authenticated
using (
  sender_id = auth.uid()
  or exists (
    select 1 from public.system_feedback f
    where f.id = feedback_id and f.user_id = auth.uid()
  )
  or exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and p.status = 'aprovado'
  )
);

create policy "feedback_messages_insert"
on public.system_feedback_messages for insert to authenticated
with check (
  sender_id = auth.uid()
  and (
    exists (
      select 1 from public.system_feedback f
      where f.id = feedback_id and f.user_id = auth.uid()
    )
    or exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin' and p.status = 'aprovado'
    )
  )
);

-- Somente o administrador pode excluir relatos.
drop policy if exists "feedback_user_delete" on public.system_feedback;
drop policy if exists "feedback_admin_delete" on public.system_feedback;
create policy "feedback_admin_delete"
on public.system_feedback for delete to authenticated
using (exists (
  select 1 from public.profiles p
  where p.id = auth.uid() and p.role = 'admin' and p.status = 'aprovado'
));

notify pgrst, 'reload schema';
