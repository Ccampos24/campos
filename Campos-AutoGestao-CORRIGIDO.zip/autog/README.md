CAMPOS AUTOMOTIVO — ETAPA 11
RELATÓRIOS

Inclui relatórios por período, status do veículo, veículo e vendedor; resumo de vendas e financeiro; detalhamento de vendas; impressão e exportação CSV.

Não é necessário SQL novo nesta etapa.
