# Documentos agrupados por veiculo

A aba Documentacao agora apresenta um unico grupo por veiculo. Cada arquivo continua armazenado individualmente no banco e no Storage para permitir abrir ou excluir um arquivo sem remover os demais. O agrupamento e visual e usa o vehicle_id existente; nao exige nova tabela nem migracao.

Publique o index.html atualizado mantendo os demais recursos da pasta.
