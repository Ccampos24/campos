-- CAMPOS AUTOGESTÃO — Histórico de atividades
-- Faça backup antes de executar. Execute uma única vez no Supabase SQL Editor.
-- O administrador geral (profiles.role='admin' e status='aprovado') pode consultar todas as lojas.
-- As alterações registram apenas metadados; nenhum CPF, telefone, e-mail ou conteúdo de campos é copiado.

begin;

alter table public.audit_logs
  add column if not exists owner_id uuid;

-- Remove a política que permitia a usuários aprovados inserir logs diretamente.
drop policy if exists audit_approved_insert on public.audit_logs;

-- A leitura continua restrita ao administrador geral pela política audit_admin_select já existente.
-- Também bloqueia INSERT direto pela API para papéis comuns; a função SECURITY DEFINER dos gatilhos
-- grava os eventos com os privilégios do proprietário da função.
revoke insert on table public.audit_logs from anon, authenticated;

create or replace function public.write_audit_log()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_row jsonb;
  v_record_id uuid;
  v_owner_id uuid;
  v_action text;
begin
  if tg_op = 'DELETE' then
    v_row := to_jsonb(old);
    v_action := 'DELETE';
  elsif tg_op = 'UPDATE' then
    v_row := to_jsonb(new);
    v_action := 'UPDATE';
  else
    v_row := to_jsonb(new);
    v_action := 'INSERT';
  end if;

  v_record_id := nullif(v_row->>'id','')::uuid;
  v_owner_id := nullif(v_row->>'owner_id','')::uuid;

  insert into public.audit_logs
    (user_id, owner_id, action, table_name, record_id, description)
  values
    (auth.uid(), v_owner_id, v_action, tg_table_name, v_record_id,
     case v_action
       when 'INSERT' then 'Registro criado'
       when 'UPDATE' then 'Registro alterado'
       when 'DELETE' then 'Registro excluído'
     end);

  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists audit_vehicles_changes on public.vehicles;
create trigger audit_vehicles_changes
after insert or update or delete on public.vehicles
for each row execute function public.write_audit_log();

drop trigger if exists audit_sales_changes on public.sales;
create trigger audit_sales_changes
after insert or update or delete on public.sales
for each row execute function public.write_audit_log();

drop trigger if exists audit_customers_changes on public.customers;
create trigger audit_customers_changes
after insert or update or delete on public.customers
for each row execute function public.write_audit_log();

drop trigger if exists audit_finance_changes on public.finance;
create trigger audit_finance_changes
after insert or update or delete on public.finance
for each row execute function public.write_audit_log();

drop trigger if exists audit_sellers_changes on public.sellers;
create trigger audit_sellers_changes
after insert or update or delete on public.sellers
for each row execute function public.write_audit_log();


drop trigger if exists audit_vehicle_documents_changes on public.vehicle_documents;
create trigger audit_vehicle_documents_changes
after insert or update or delete on public.vehicle_documents
for each row execute function public.write_audit_log();

commit;
