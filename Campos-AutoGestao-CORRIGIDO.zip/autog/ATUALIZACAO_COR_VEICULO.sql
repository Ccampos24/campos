-- Campos AutoGestão: adicionar cor livre ao cadastro de veículos
ALTER TABLE public.vehicles
ADD COLUMN IF NOT EXISTS color TEXT;

-- Atualiza o cache de esquema usado pelo Supabase/PostgREST
NOTIFY pgrst, 'reload schema';
