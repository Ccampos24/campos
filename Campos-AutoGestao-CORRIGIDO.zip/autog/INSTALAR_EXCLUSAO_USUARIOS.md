# Exclusão de usuários pelo painel administrativo

Esta atualização adiciona o botão **Excluir** em Administração → Usuários cadastrados.
O botão não exclui a própria conta logada, exige digitar `EXCLUIR` e chama uma Supabase Edge Function protegida.

## O que a função faz

- Confere a sessão e valida que quem chamou é administrador aprovado.
- Impede autoexclusão e impede remover o último administrador aprovado.
- Atualiza `updated_by` em `system_settings` e `system_feedback` para o administrador executor, preservando os registros compartilhados e o histórico de autoria.
- Exclui dados do usuário-alvo em `system_feedback_messages`, `system_feedback`, `sales`, `finance`, `vehicle_documents`, `customers`, `sellers` e `vehicles`.
- Por fim, exclui a conta em Supabase Auth.
- Nunca recebe nem coloca a chave `service_role` no navegador.

**Atenção:** a exclusão dos dados comerciais é definitiva. Faça backup do projeto antes de habilitar a função. Se o seu banco tiver outras tabelas próprias com FK para `auth.users` ou para as tabelas listadas, inclua-as na função na ordem correta antes de publicar.

## Publicar

1. Faça backup do banco.
2. Na pasta `autog`, instale/abra o Supabase CLI e faça login: `supabase login`.
3. Vincule o projeto: `supabase link --project-ref gzymhqdbrqcsinsykyee`.
4. Publique a função: `supabase functions deploy admin-delete-user`.
5. No painel Supabase → Edge Functions → `admin-delete-user` → Secrets, confirme que `SUPABASE_URL`, `SUPABASE_ANON_KEY` e `SUPABASE_SERVICE_ROLE_KEY` estão configuradas. As variáveis padrão do projeto costumam estar disponíveis automaticamente; nunca exponha a `service_role` no HTML.
6. Publique o `index.html` atualizado no Cloudflare junto com os demais arquivos do site.
7. Entre como administrador aprovado, abra Administração e teste primeiro com um usuário de teste.

Se preferir CLI para os secrets, configure `SUPABASE_SERVICE_ROLE_KEY` usando a chave secreta do projeto em ambiente seguro; não a coloque em arquivos públicos nem envie em conversas.
