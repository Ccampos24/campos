CAMPOS AUTOGESTÃO — ISOLAMENTO DE CONTAS

1. Faça backup do projeto Supabase antes de migrar.
2. No Supabase, abra SQL Editor e execute SEGURANCA_USUARIOS.sql.
3. Publique/substitua o index.html atualizado junto com os arquivos de imagem.
4. Teste com duas contas distintas: cadastre veículos/clientes/vendas em cada conta e confirme que não aparecem cruzados.

A migração protege vehicles, sales, customers, finance e sellers com Row Level Security e owner_id. Registros antigos com created_by são atribuídos ao respectivo autor; os sem autor são atribuídos ao primeiro administrador aprovado. O administrador mantém a gestão de contas/perfis, mas os dados operacionais ficam isolados por usuário.
