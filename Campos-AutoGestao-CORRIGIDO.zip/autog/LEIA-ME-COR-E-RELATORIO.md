# Atualização: cor do veículo e detalhamento das vendas

## 1. Atualize o banco Supabase
No Supabase, abra **SQL Editor → New query**, execute o conteúdo de `ATUALIZACAO_COR_VEICULO.sql` e aguarde a confirmação de sucesso.

## 2. Atualize os arquivos do sistema
Publique/substitua os arquivos do sistema pelo conteúdo deste ZIP. Depois atualize a página com `Ctrl + F5`.

## Alterações
- Novo campo de texto livre **Cor do veículo** no cadastro e edição do veículo.
- A cor aparece na listagem de veículos.
- O detalhamento das vendas e o relatório impresso incluem cor, RENAVAM, placa, combustível, ano e valor de compra.
- O valor de compra aparece também na tabela principal de vendas.
- A exportação CSV inclui os mesmos dados do veículo e valor de compra.

A cor é armazenada em `public.vehicles.color`. Os dados do veículo nos relatórios são obtidos do cadastro vinculado à venda.
